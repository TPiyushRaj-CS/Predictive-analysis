# %% [markdown]
# # Predictive Analytics Using Historical Data
# **Goal:** build a model that forecasts future sales trends from historical monthly data.
#
# **Pipeline:** load data, clean and pre-process, explore trend and seasonality, build models
# (regression and time-series), evaluate accuracy, visualise, forecast the next 12 months.
#
# > Data note: `sales_data.csv` is a **synthetic** monthly retail-sales dataset created for this
# > demo (with realistic trend, seasonality, noise, missing values, duplicates and outliers).
# > To use real data, replace the file with a CSV that has columns `Date` and `Sales`.

# %% [markdown]
# ## 1. Setup

# %%
import json
import os
import warnings

import matplotlib
import numpy as np
import pandas as pd

try:
    get_ipython()            # running inside Jupyter: show charts inline
except NameError:
    matplotlib.use("Agg")    # running as a script: save charts only
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

warnings.filterwarnings("ignore")
DATA_PATH, CHART_DIR, RESULT_DIR = "sales_data.csv", "charts", "results"
HORIZON = 12          # forecast / test length in months
for d in (CHART_DIR, RESULT_DIR):
    os.makedirs(d, exist_ok=True)

NAVY, ORANGE, GREEN, RED, GREY = "#1F4E79", "#EF6C00", "#2E7D32", "#C62828", "#7F8C8D"
plt.rcParams.update({"figure.dpi": 130, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": 0.25, "font.size": 10})


def save(fig, name):
    fig.tight_layout()
    fig.savefig(f"{CHART_DIR}/{name}.png", dpi=170)
    plt.show() if matplotlib.get_backend().lower() != "agg" else plt.close(fig)


# %% [markdown]
# ## 2. Data (synthetic demo dataset, skip this cell if you have your own `sales_data.csv`)

# %%
def make_synthetic_data(path):
    rng = np.random.default_rng(42)
    dates = pd.date_range("2015-01-01", "2025-12-01", freq="MS")
    t = np.arange(len(dates))
    season = np.array([0.88, 0.85, 0.95, 0.97, 1.00, 0.98, 0.96, 1.00, 1.02, 1.08, 1.22, 1.35])
    season = season / season.mean()
    sales = 25000 * 1.005 ** t * season[dates.month - 1] * rng.lognormal(0, 0.035, len(t))
    df = pd.DataFrame({"Date": dates.strftime("%Y-%m-%d"), "Sales": sales.round(2)})
    # inject typical data-quality problems
    df.loc[[20, 47, 81, 100], "Sales"] = np.nan                  # missing values
    df.loc[[33, 70, 112], "Sales"] *= [2.6, 0.35, 2.2]           # outliers (typos / one-offs)
    df = pd.concat([df, df.iloc[[10, 60]]]).sort_values("Date")  # duplicate rows
    df.to_csv(path, index=False)


if not os.path.exists(DATA_PATH):
    make_synthetic_data(DATA_PATH)
raw = pd.read_csv(DATA_PATH)
print(raw.shape)
print(raw.head())

# %% [markdown]
# ## 3. Data cleaning and pre-processing
# Steps: parse dates, remove duplicates, enforce a regular monthly index, find missing values,
# detect outliers (robust z-score on the de-trended, de-seasonalised log series), and replace
# bad points with a trend + seasonality estimate (better than plain linear interpolation for
# seasonal data).

# %%
raw["Date"] = pd.to_datetime(raw["Date"], errors="coerce")
n_rows_raw = len(raw)
n_duplicates = int(raw.duplicated(subset="Date").sum())
df = (raw.dropna(subset=["Date"]).drop_duplicates(subset="Date")
         .sort_values("Date").set_index("Date").asfreq("MS"))
n_missing = int(df["Sales"].isna().sum())

log_s = np.log(df["Sales"])
trend = log_s.rolling(12, center=True, min_periods=6).mean()
detr = log_s - trend
month_eff = detr.groupby(detr.index.month).median()
resid = detr - month_eff.reindex(detr.index.month).values
mad = (resid - resid.median()).abs().median()
robust_z = 0.6745 * (resid - resid.median()) / mad
is_outlier = robust_z.abs() > 3.5
n_outliers = int(is_outlier.sum())

estimate = np.exp(trend.interpolate(limit_direction="both") + month_eff.reindex(df.index.month).values)
clean = df["Sales"].copy()
fix_mask = is_outlier | clean.isna()
clean[fix_mask] = estimate[fix_mask]
clean = clean.interpolate(limit_direction="both")
data = pd.DataFrame({"Sales_raw": df["Sales"], "Sales": clean, "Fixed": fix_mask})
data.to_csv(f"{RESULT_DIR}/cleaned_data.csv")

print(f"Rows in file: {n_rows_raw} | duplicates removed: {n_duplicates} | "
      f"missing: {n_missing} | outliers: {n_outliers} | final months: {len(data)}")

fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(data.index, data["Sales_raw"], color=GREY, lw=1.2, label="Raw (with gaps and outliers)")
ax.plot(data.index, data["Sales"], color=NAVY, lw=1.6, label="Cleaned")
ax.scatter(data.index[data["Fixed"]], data["Sales"][data["Fixed"]], color=RED, zorder=5, s=36,
           label=f"Fixed points ({int(data['Fixed'].sum())})")
ax.set(title="Step 1: Data cleaning, raw vs cleaned monthly sales", ylabel="Sales")
ax.legend()
save(fig, "01_cleaning")

# %% [markdown]
# ## 4. Exploratory analysis: trend and seasonality

# %%
s = data["Sales"]
annual = s.groupby(s.index.year).sum()
cagr = (annual.iloc[-1] / annual.iloc[0]) ** (1 / (len(annual) - 1)) - 1
peak_month = s.groupby(s.index.month).mean().idxmax()

fig, axes = plt.subplots(1, 2, figsize=(11, 4), gridspec_kw={"width_ratios": [1.1, 1]})
ax = axes[0]
ax.plot(s.index, s, color=GREY, lw=1, label="Monthly sales")
ax.plot(s.rolling(12, center=True).mean(), color=ORANGE, lw=2.4, label="12-month trend")
ax.set(title="Trend", ylabel="Sales"); ax.legend()
pivot = s.groupby([s.index.year, s.index.month]).sum().unstack()
sns.heatmap(pivot, cmap="Blues", ax=axes[1], cbar_kws={"label": "Sales"})
axes[1].set(title="Seasonality heatmap (year x month)", xlabel="Month", ylabel="")
save(fig, "02_trend_seasonality")
print(f"Annual growth (CAGR): {cagr:.1%} | Peak month: {peak_month}")

# %% [markdown]
# ## 5. Models
# | Model | Type | Idea |
# |---|---|---|
# | Seasonal Naive | baseline | same month last year |
# | Linear Regression | regression | log-linear trend + month dummies |
# | Ridge | regression | regularised, uses lag features |
# | Random Forest | ML regression | non-linear, uses lag features |
# | Gradient Boosting | ML regression | non-linear, uses lag features |
#
# For the lag models the target is the **year-over-year ratio** (`y / y(t-12)`). This makes the
# problem scale-free so tree models can handle a growing series (trees cannot extrapolate a trend).
# Forecasts are **recursive**: each predicted month is fed back as history for the next one.

# %%
LAGS = [1, 2, 3, 6]


def lag_features(hist, date):
    base = hist.iloc[-12]
    f = {"m_sin": np.sin(2 * np.pi * date.month / 12), "m_cos": np.cos(2 * np.pi * date.month / 12),
         "yoy_prev": hist.iloc[-12] / hist.iloc[-24]}
    for k in LAGS:
        f[f"lag{k}_rel"] = hist.iloc[-k] / base
    f["roll3_rel"] = hist.iloc[-3:].mean() / base
    f["roll12_rel"] = hist.iloc[-12:].mean() / base
    return f


def build_training(train):
    rows, y = [], []
    for i in range(24, len(train)):
        hist = train.iloc[:i]
        rows.append(lag_features(hist, train.index[i]))
        y.append(train.iloc[i] / hist.iloc[-12])
    return pd.DataFrame(rows), np.array(y)


def make_model(name):
    return {"Ridge (lags)": Ridge(alpha=1.0),
            "Random Forest (lags)": RandomForestRegressor(n_estimators=400, min_samples_leaf=2, random_state=0),
            "Gradient Boosting (lags)": GradientBoostingRegressor(n_estimators=300, learning_rate=0.03,
                                                                  max_depth=2, subsample=0.8, random_state=0)}[name]


def forecast(name, train, horizon=HORIZON):
    idx = pd.date_range(train.index[-1] + pd.offsets.MonthBegin(1), periods=horizon, freq="MS")
    if name == "Seasonal Naive":
        return pd.Series(train.iloc[-12:].values[np.arange(horizon) % 12], index=idx)
    if name == "Linear Regression (trend+season)":
        def design(index, t0):
            X = pd.get_dummies(pd.Series(index.month, index=index).astype(str)).reindex(
                columns=[str(m) for m in range(1, 13)], fill_value=0).astype(float)
            X["t"] = np.arange(t0, t0 + len(index))
            return X
        m = LinearRegression().fit(design(train.index, 0), np.log(train.values))
        return pd.Series(np.exp(m.predict(design(idx, len(train)))), index=idx)
    X, y = build_training(train)
    model = make_model(name).fit(X, y)
    hist = train.copy()
    for d in idx:
        ratio = model.predict(pd.DataFrame([lag_features(hist, d)]))[0]
        hist.loc[d] = hist.iloc[-12] * ratio
    return hist.iloc[-horizon:]


MODELS = ["Seasonal Naive", "Linear Regression (trend+season)", "Ridge (lags)",
          "Random Forest (lags)", "Gradient Boosting (lags)"]


def metrics(actual, pred):
    return {"MAE": mean_absolute_error(actual, pred),
            "RMSE": float(np.sqrt(mean_squared_error(actual, pred))),
            "MAPE_%": float(np.mean(np.abs((actual - pred) / actual)) * 100),
            "R2": r2_score(actual, pred)}


# %% [markdown]
# ## 6. Evaluation
# 1. **Hold-out test:** train on everything except the last 12 months, forecast those 12 months.
# 2. **Rolling-origin cross-validation:** 4 expanding-window folds, each forecasting the next 12 months.
#    Time-series data must never be shuffled, so training data always comes before test data.

# %%
train, test = s.iloc[:-HORIZON], s.iloc[-HORIZON:]
holdout_preds = {m: forecast(m, train) for m in MODELS}
holdout = pd.DataFrame({m: metrics(test, p) for m, p in holdout_preds.items()}).T

cv_rows = {m: [] for m in MODELS}
for k in range(4, 0, -1):
    cut = len(s) - HORIZON * k
    tr, te = s.iloc[:cut], s.iloc[cut:cut + HORIZON]
    for m in MODELS:
        cv_rows[m].append(metrics(te, forecast(m, tr)))
cv = pd.DataFrame({m: pd.DataFrame(r).mean() for m, r in cv_rows.items()}).T
cv.columns = [f"CV_{c}" for c in cv.columns]
table = holdout.join(cv).round(3).sort_values("CV_MAPE_%")
table.to_csv(f"{RESULT_DIR}/model_comparison.csv")
print(table[["MAE", "RMSE", "MAPE_%", "R2", "CV_RMSE", "CV_MAPE_%"]])

best = table.index[0]
print("\nBest model (lowest cross-validated MAPE):", best)

fig, axes = plt.subplots(1, 2, figsize=(11, 4))
order = table.index[::-1]
axes[0].barh(order, table.loc[order, "CV_MAPE_%"], color=[GREEN if m == best else GREY for m in order])
axes[0].set(title="Cross-validated MAPE (%), lower is better", xlabel="MAPE %")
axes[1].barh(order, table.loc[order, "CV_RMSE"], color=[GREEN if m == best else GREY for m in order])
axes[1].set(title="Cross-validated RMSE, lower is better", xlabel="RMSE"); axes[1].set_yticklabels([])
save(fig, "03_model_comparison")

fig, ax = plt.subplots(figsize=(10, 4.2))
ax.plot(s.iloc[-36:], color="black", lw=2, label="Actual")
colors = [GREY, ORANGE, "#8E44AD", RED, GREEN]
for (m, p), c in zip(holdout_preds.items(), colors):
    ax.plot(p, lw=1.8 if m == best else 1.1, ls="-" if m == best else "--", color=c, label=m)
ax.axvline(test.index[0], color="k", ls=":", lw=1)
ax.text(test.index[0], ax.get_ylim()[1], " test period", va="top", fontsize=9)
ax.set(title="Hold-out test: actual vs predicted (last 12 months)", ylabel="Sales")
ax.legend(fontsize=8, ncol=2)
save(fig, "04_actual_vs_predicted")

# %% [markdown]
# ## 7. Residual diagnostics and feature importance

# %%
res = test - holdout_preds[best]
X_all, y_all = build_training(s)
gb = make_model("Gradient Boosting (lags)").fit(X_all, y_all)
imp = pd.Series(gb.feature_importances_, index=X_all.columns).sort_values()

fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
axes[0].bar(res.index.strftime("%b %y"), res.values / test.values * 100, color=[GREEN if v >= 0 else RED for v in res])
axes[0].axhline(0, color="k", lw=0.8)
axes[0].set(title=f"Hold-out error by month, {best} (%)", ylabel="Actual minus predicted (% of actual)")
axes[0].tick_params(axis="x", rotation=60)
axes[1].barh(imp.index, imp.values, color=NAVY)
axes[1].set(title="What drives the forecast? (Gradient Boosting importance)")
save(fig, "05_diagnostics")

# %% [markdown]
# ## 8. Final forecast (next 12 months)
# The best model is re-trained on **all** the data. The shaded band is an approximate 95% range
# built from the model's cross-validated RMSE (it is a rough guide, not an exact interval).

# %%
fc = forecast(best, s)
band = 1.96 * table.loc[best, "CV_RMSE"]
fc_df = pd.DataFrame({"Forecast": fc.round(0), "Lower_95": (fc - band).round(0), "Upper_95": (fc + band).round(0)})
fc_df.index.name = "Date"
fc_df.to_csv(f"{RESULT_DIR}/forecast_next_12_months.csv")
print(fc_df)

fig, ax = plt.subplots(figsize=(10, 4.2))
ax.plot(s.iloc[-48:], color=NAVY, lw=2, label="Historical (cleaned)")
ax.plot(fc, color=ORANGE, lw=2.2, marker="o", ms=4, label=f"Forecast ({best})")
ax.fill_between(fc.index, fc - band, fc + band, color=ORANGE, alpha=0.18, label="Approx. 95% range")
ax.axvline(s.index[-1], color="k", ls=":", lw=1)
ax.set(title="Forecast: next 12 months of sales", ylabel="Sales"); ax.legend()
save(fig, "06_forecast")

yoy = fc.sum() / s.iloc[-12:].sum() - 1
print(f"Forecast total next 12 months: {fc.sum():,.0f} ({yoy:+.1%} vs last 12 months)")

# %% [markdown]
# ## 9. Save summary for the report

# %%
summary = {
    "rows_raw": n_rows_raw, "duplicates": n_duplicates, "missing": n_missing, "outliers": n_outliers,
    "months": len(s), "start": str(s.index[0].date()), "end": str(s.index[-1].date()),
    "cagr": float(cagr), "peak_month": int(peak_month), "best_model": best,
    "forecast_total": float(fc.sum()), "forecast_vs_last12": float(yoy),
    "table": table.reset_index().rename(columns={"index": "Model"}).to_dict(orient="records"),
    "forecast": [{"Date": d.strftime("%b %Y"), "Forecast": float(r.Forecast), "Lower": float(r.Lower_95),
                  "Upper": float(r.Upper_95)} for d, r in fc_df.iterrows()],
}
json.dump(summary, open(f"{RESULT_DIR}/summary.json", "w"), indent=2)
print("Done. Charts in ./charts, tables in ./results")
